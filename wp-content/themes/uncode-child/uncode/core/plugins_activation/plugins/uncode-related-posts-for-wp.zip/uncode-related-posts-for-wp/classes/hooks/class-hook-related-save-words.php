<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class RP4WP_Hook_Related_Save_Words extends RP4WP_Hook {
	protected $tag = 'transition_post_status';
	protected $args = 3;

	public function run( $new_status, $old_status, $post ) {

		global $uncode_related_post_types;
    if (!isset($uncode_related_post_types)) $uncode_related_post_types = uncode_get_post_types(true);

		// verify this is not an auto save routine.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( !in_array($post->post_type, $uncode_related_post_types )) {
			return;
		}

		// Post status must be publish
		if ( 'publish' != $new_status ) {
			return;
		}

		// Save Words
		$related_word_manager = new RP4WP_Related_Word_Manager();
		$related_word_manager->save_words_of_post( $post->ID );

	}
}