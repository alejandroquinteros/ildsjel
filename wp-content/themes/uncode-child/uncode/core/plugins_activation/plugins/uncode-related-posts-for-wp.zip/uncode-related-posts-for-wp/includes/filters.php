<?php

return array(
	'after_post',
	'plugin_links',
	'set_screen_option'
);